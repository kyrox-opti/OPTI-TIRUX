const { app, BrowserWindow, ipcMain, shell } = require('electron');
const path = require('node:path');
const os = require('node:os');
const fs = require('node:fs/promises');
const { execFile } = require('node:child_process');
const { promisify } = require('node:util');
const crypto = require('node:crypto');
const execFileAsync = promisify(execFile);
const si = require('systeminformation');
let previousPowerScheme = null;
let dpcTraceActive = false;
let restoringOnQuit = false;
const changedPriorities = new Map();
let ownedPowerSchemes = new Set();

async function runPowerShell(script, timeout = 30000) {
  if (process.platform !== 'win32') throw new Error('Esta función solo está disponible en Windows.');
  const encoded = Buffer.from(script, 'utf16le').toString('base64');
  const { stdout } = await execFileAsync('powershell.exe', ['-NoProfile', '-NonInteractive', '-EncodedCommand', encoded], { windowsHide: true, timeout, maxBuffer: 8 * 1024 * 1024 });
  return stdout.trim();
}

async function loadPreviousPowerScheme() {
  try { const file = path.join(app.getPath('userData'), 'previous-power-scheme.json'); const saved = JSON.parse(await fs.readFile(file, 'utf8')); if (typeof saved.guid === 'string' && /^[0-9a-fA-F-]{36}$/.test(saved.guid)) previousPowerScheme = saved.guid; } catch {}
}
async function savePreviousPowerScheme() {
  const file = path.join(app.getPath('userData'), 'previous-power-scheme.json');
  await fs.mkdir(path.dirname(file), { recursive: true });
  if (previousPowerScheme) await fs.writeFile(file, JSON.stringify({ guid: previousPowerScheme, savedAt: new Date().toISOString() }, null, 2), 'utf8');
  else await fs.rm(file, { force: true });
}
async function loadOwnedPowerSchemes() {
  try {
    const file = path.join(app.getPath('userData'), 'owned-power-schemes.json');
    const ids = JSON.parse(await fs.readFile(file, 'utf8'));
    if (Array.isArray(ids)) ownedPowerSchemes = new Set(ids.filter(x => typeof x === 'string' && /^[0-9a-fA-F-]{36}$/.test(x)));
  } catch { ownedPowerSchemes = new Set(); }
}
async function saveOwnedPowerSchemes() {
  const file = path.join(app.getPath('userData'), 'owned-power-schemes.json');
  await fs.mkdir(path.dirname(file), { recursive: true });
  await fs.writeFile(file, JSON.stringify([...ownedPowerSchemes], null, 2), 'utf8');
}
async function saveDpcMarker() {
  const file = path.join(app.getPath('userData'), 'dpc-active.json');
  await fs.mkdir(path.dirname(file), { recursive: true });
  await fs.writeFile(file, JSON.stringify({ startedAt: new Date().toISOString() }, null, 2), 'utf8');
}
async function clearDpcMarker() {
  await fs.rm(path.join(app.getPath('userData'), 'dpc-active.json'), { force: true });
}
async function loadDpcMarker() {
  try { await fs.access(path.join(app.getPath('userData'), 'dpc-active.json')); dpcTraceActive = true; } catch { dpcTraceActive = false; }
}
async function persistPriorityBackups() {
  const file = path.join(app.getPath('userData'), 'priority-backups.json');
  await fs.mkdir(path.dirname(file), { recursive: true });
  await fs.writeFile(file, JSON.stringify([...changedPriorities.entries()], null, 2), 'utf8');
}
async function restorePriorityBackups() {
  const restored = []; const failures = [];
  for (const [pid, previous] of changedPriorities.entries()) {
    try {
      const name = previous.name.replace(/'/g, "''");
      const startTicks = Number(previous.startTicks) || 0;
      await runPowerShell(`$p=Get-Process -Id ${pid} -ErrorAction Stop; if($p.ProcessName -ne '${name}') { throw 'PID reutilizado.' }; $expected=${startTicks}; if($expected -gt 0 -and $p.StartTime.ToUniversalTime().Ticks -ne $expected) { throw 'Instancia de proceso distinta.' }; $p.PriorityClass=[System.Diagnostics.ProcessPriorityClass]::${previous.priority}`, 8000);
      restored.push(pid);
    } catch (e) { failures.push({ pid, error: e.message }); }
  }
  changedPriorities.clear();
  await persistPriorityBackups().catch(() => {});
  return { restored, failures };
}
async function loadPriorityBackups() {
  try {
    const file = path.join(app.getPath('userData'), 'priority-backups.json');
    const entries = JSON.parse(await fs.readFile(file, 'utf8'));
    if (Array.isArray(entries)) for (const entry of entries) {
      if (Array.isArray(entry) && Number.isInteger(Number(entry[0])) && entry[1] && typeof entry[1].name === 'string' && ['Idle','BelowNormal','Normal','AboveNormal','High','Realtime'].includes(entry[1].priority)) changedPriorities.set(Number(entry[0]), { name: entry[1].name, priority: entry[1].priority, startTicks: Number(entry[1].startTicks) || 0 });
    }
  } catch {}
}

async function isAdmin() {
  try { return (await runPowerShell('[Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator')).toLowerCase() === 'true'; } catch { return false; }
}

async function getPowerSchemes() {
  const { stdout } = await execFileAsync('powercfg.exe', ['/list'], { windowsHide: true, timeout: 10000 });
  const active = stdout.match(/\*\s*([0-9a-fA-F-]{36})/);
  const schemes = [...stdout.matchAll(/([0-9a-fA-F-]{36})\s*\(([^)]+)\)/g)].map(m => ({ guid: m[1], name: m[2], active: !!active && active[1].toLowerCase() === m[1].toLowerCase() }));
  return schemes;
}

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1500,
    height: 960,
    minWidth: 1080,
    minHeight: 700,
    backgroundColor: '#08070D',
    title: 'OPTI TIRUX',
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });

  mainWindow.loadFile(path.join(__dirname, '..', 'src', 'index.html'));
  mainWindow.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
}

function safeTempRoots() {
  const roots = [os.tmpdir()];
  if (process.platform === 'win32' && process.env.LOCALAPPDATA) {
    roots.push(path.join(process.env.LOCALAPPDATA, 'Temp'));
  }
  return [...new Set(roots.map(p => path.resolve(p)))];
}

async function collectOldTempFiles() {
  const cutoff = Date.now() - 7 * 24 * 60 * 60 * 1000;
  const roots = safeTempRoots();
  const found = [];
  const maxFiles = 25000;

  async function walk(dir, root) {
    if (found.length >= maxFiles) return;
    let entries;
    try { entries = await fs.readdir(dir, { withFileTypes: true }); }
    catch { return; }

    for (const entry of entries) {
      if (found.length >= maxFiles) break;
      const full = path.join(dir, entry.name);
      try {
        const st = await fs.lstat(full);
        if (st.isSymbolicLink()) continue;
        if (st.isDirectory()) {
          await walk(full, root);
        } else if (st.isFile() && st.mtimeMs < cutoff) {
          const resolved = path.resolve(full);
          if (resolved.startsWith(root + path.sep)) {
            found.push({ path: resolved, size: st.size });
          }
        }
      } catch { /* file in use, inaccessible, or removed: skip */ }
    }
  }

  for (const root of roots) await walk(root, root);
  return found;
}

ipcMain.handle('system:info', async () => {
  const safe = (fn, fallback) => fn().catch(() => fallback);
  const [cpu, osInfo, mem, load, graphics, disks, temperature, processes] = await Promise.all([
    safe(() => si.cpu(), {}), safe(() => si.osInfo(), {}), safe(() => si.mem(), {}),
    safe(() => si.currentLoad(), {}), safe(() => si.graphics(), { controllers: [] }),
    safe(() => si.fsSize(), []), safe(() => si.cpuTemperature(), { main: -1 }),
    safe(() => si.processes(), {})
  ]);

  const gpu = (graphics.controllers || []).map(g => ({
    model: g.model || 'GPU',
    vendor: g.vendor || null,
    utilization: Number.isFinite(g.utilizationGpu) ? g.utilizationGpu : null,
    temperature: Number.isFinite(g.temperatureGpu) ? g.temperatureGpu : null
  }));

  return {
    platform: process.platform,
    os: `${osInfo.distro || osInfo.platform || 'Windows'} ${osInfo.release || ''}`.trim(),
    hostname: os.hostname(),
    cpu: { manufacturer: cpu.manufacturer, brand: cpu.brand, cores: cpu.cores, physicalCores: cpu.physicalCores },
    cpuLoad: Number.isFinite(load.currentLoad) ? load.currentLoad : null,
    memory: { total: mem.total, used: mem.active, available: mem.available, percent: mem.total ? (mem.active / mem.total) * 100 : null },
    gpu,
    cpuTemperature: Number.isFinite(temperature.main) && temperature.main > 0 ? temperature.main : null,
    disks: (disks || []).map(d => ({ fs: d.fs, mount: d.mount, size: d.size, used: d.used, use: d.use })),
    processCount: processes.all || null,
    collectedAt: new Date().toISOString()
  };
});

ipcMain.handle('processes:list', async () => {
  const result = await si.processes();
  return (result.list || []).map(p => ({
    pid: p.pid,
    name: p.name || p.command || 'Unknown',
    cpu: Number.isFinite(p.cpu) ? p.cpu : null,
    memory: Number.isFinite(p.mem) ? p.mem : null,
    state: p.state || 'Unknown',
    threads: Number.isFinite(p.threads) ? p.threads : null,
    handles: null
  })).sort((a, b) => (b.cpu ?? -1) - (a.cpu ?? -1)).slice(0, 250);
});

ipcMain.handle('temp:scan', async () => {
  const files = await collectOldTempFiles();
  return {
    count: files.length,
    bytes: files.reduce((sum, f) => sum + f.size, 0),
    ageDays: 7,
    capped: files.length >= 25000
  };
});

ipcMain.handle('temp:clean', async () => {
  const files = await collectOldTempFiles();
  let deleted = 0, bytes = 0, skipped = 0;
  for (const file of files) {
    try {
      await fs.unlink(file.path);
      deleted++;
      bytes += file.size;
    } catch { skipped++; }
  }
  return { deleted, bytes, skipped, completedAt: new Date().toISOString() };
});

async function admPasswordFile() { return path.join(app.getPath('userData'), 'adm-password.json'); }
ipcMain.handle('adm:password-status', async () => {
  try { const saved = JSON.parse(await fs.readFile(await admPasswordFile(), 'utf8')); return { configured: !!(saved.salt && saved.hash) }; }
  catch { return { configured: false }; }
});
ipcMain.handle('adm:password-set', async (_event, password) => {
  if (typeof password !== 'string' || password.length < 10 || password.length > 128) throw new Error('La contraseña debe tener entre 10 y 128 caracteres.');
  const file = await admPasswordFile();
  try { await fs.access(file); throw new Error('Ya existe una contraseña ADM. Usa la verificación para entrar.'); } catch (e) { if (e.message.includes('Ya existe')) throw e; }
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(password, salt, 64);
  await fs.writeFile(file, JSON.stringify({ salt: salt.toString('hex'), hash: hash.toString('hex'), createdAt: new Date().toISOString() }, null, 2), { encoding: 'utf8', mode: 0o600 });
  return { configured: true };
});
ipcMain.handle('adm:password-verify', async (_event, password) => {
  if (typeof password !== 'string' || password.length > 128) return { valid: false };
  try {
    const saved = JSON.parse(await fs.readFile(await admPasswordFile(), 'utf8'));
    const salt = Buffer.from(saved.salt, 'hex'); const expected = Buffer.from(saved.hash, 'hex');
    const actual = crypto.scryptSync(password, salt, expected.length);
    return { valid: expected.length === actual.length && crypto.timingSafeEqual(expected, actual) };
  } catch { return { valid: false }; }
});

ipcMain.handle('adm:overview', async () => {
  if (process.platform !== 'win32') throw new Error('ADM avanzado requiere Windows 10/11.');
  const [admin, schemes, driversRaw, problemRaw, startupRaw, timerRaw] = await Promise.all([
    isAdmin(), getPowerSchemes().catch(() => []),
    runPowerShell("Get-CimInstance Win32_PnPSignedDriver | Select-Object DeviceName,DriverVersion,DriverDate,Manufacturer,InfName | ConvertTo-Json -Depth 3 -Compress", 45000).catch(() => '[]'),
    runPowerShell("Get-PnpDevice -PresentOnly | Where-Object {$_.Status -ne 'OK'} | Select-Object Status,Class,FriendlyName,InstanceId | ConvertTo-Json -Depth 3 -Compress", 30000).catch(() => '[]'),
    runPowerShell("Get-CimInstance Win32_StartupCommand | Select-Object Name,Command,Location,User | ConvertTo-Json -Depth 3 -Compress", 30000).catch(() => '[]'),
    runPowerShell("Add-Type -TypeDefinition 'using System; using System.Runtime.InteropServices; public class NativeTimer { [DllImport(\"ntdll.dll\")] public static extern int NtQueryTimerResolution(out uint min, out uint max, out uint current); }'; $min=0; $max=0; $cur=0; [NativeTimer]::NtQueryTimerResolution([ref]$min,[ref]$max,[ref]$cur) | Out-Null; [pscustomobject]@{Minimum100ns=$min;Maximum100ns=$max;Current100ns=$cur;CurrentMs=([double]$cur/10000)} | ConvertTo-Json -Compress", 15000).catch(() => '{}')
  ]);
  const parse = raw => { try { const v = JSON.parse(raw || '[]'); return Array.isArray(v) ? v : (v ? [v] : []); } catch { return []; } };
  const timer = (() => { try { return JSON.parse(timerRaw || '{}'); } catch { return {}; } })();
  const tool = async name => { try { await execFileAsync('where.exe', [name], { windowsHide: true, timeout: 5000 }); return true; } catch { return false; } };
  const [wpr, wpa, latencyMon, wprStatus] = await Promise.all([
    tool('wpr.exe'), tool('wpa.exe'), tool('LatencyMon.exe'),
    execFileAsync('wpr.exe', ['-status'], { windowsHide: true, timeout: 10000 }).then(x => x.stdout || '').catch(() => '')
  ]);
  if (dpcTraceActive && /no tracing sessions are currently running|no active recording|no hay.*(sesion|grabaci)/i.test(wprStatus)) { dpcTraceActive = false; await clearDpcMarker(); }
  return { admin, schemes: schemes.map(x => ({...x, owned: ownedPowerSchemes.has(x.guid.toLowerCase()) || ownedPowerSchemes.has(x.guid)})), drivers: parse(driversRaw), problemDevices: parse(problemRaw), startup: parse(startupRaw), timerResolution: timer, tools: { wpr, wpa, latencyMon }, ownedPowerSchemes: [...ownedPowerSchemes], dpcTraceActive, collectedAt: new Date().toISOString() };
});

ipcMain.handle('power:set', async (_event, guid) => {
  if (process.platform !== 'win32') throw new Error('Solo disponible en Windows.');
  if (typeof guid !== 'string' || !/^[0-9a-fA-F-]{36}$/.test(guid)) throw new Error('Identificador de plan no válido.');
  const schemes = await getPowerSchemes();
  const selected = schemes.find(x => x.guid.toLowerCase() === guid.toLowerCase());
  if (!selected) throw new Error('Ese plan no aparece entre los planes instalados.');
  const current = schemes.find(x => x.active);
  if (current && current.guid.toLowerCase() !== selected.guid.toLowerCase()) { previousPowerScheme = current.guid; await savePreviousPowerScheme(); }
  await execFileAsync('powercfg.exe', ['/setactive', selected.guid], { windowsHide: true, timeout: 10000 });
  return { active: selected, previous: previousPowerScheme };
});

ipcMain.handle('power:restore', async () => {
  if (!previousPowerScheme) throw new Error('No hay un plan anterior guardado para restaurar.');
  const schemes = await getPowerSchemes();
  if (!schemes.some(x => x.guid.toLowerCase() === previousPowerScheme.toLowerCase())) throw new Error('El plan anterior ya no está instalado.');
  await execFileAsync('powercfg.exe', ['/setactive', previousPowerScheme], { windowsHide: true, timeout: 10000 });
  const restored = previousPowerScheme; previousPowerScheme = null; await savePreviousPowerScheme();
  return { restored };
});

ipcMain.handle('timer:consistency', async () => {
  if (process.platform !== 'win32') throw new Error('Solo disponible en Windows.');
  const script = String.raw`
$source = @'
using System;
using System.Diagnostics;
public static class OptiTimerConsistency {
  public static object Run() {
    const int count = 500000;
    long[] samples = new long[count];
    long freq = Stopwatch.Frequency;
    for (int i=0; i<20000; i++) Stopwatch.GetTimestamp();
    long startAll = Stopwatch.GetTimestamp();
    long last = Stopwatch.GetTimestamp();
    for (int i=0; i<count; i++) {
      long now = Stopwatch.GetTimestamp();
      samples[i] = now - last;
      last = now;
    }
    long endAll = Stopwatch.GetTimestamp();
    Array.Sort(samples);
    long total = 0, zeros = 0;
    foreach (long v in samples) { total += v; if (v == 0) zeros++; }
    Func<int,double> us = i => samples[Math.Min(count-1, Math.Max(0, i))] * 1000000.0 / freq;
    return new {
      Samples = count,
      ElapsedMs = Math.Round((endAll-startAll)*1000.0/freq, 2),
      MeanMicroseconds = Math.Round(total*1000000.0/(freq*count), 4),
      MedianMicroseconds = Math.Round(us(count/2), 4),
      P95Microseconds = Math.Round(us((int)(count*.95)), 4),
      P99Microseconds = Math.Round(us((int)(count*.99)), 4),
      MaxMicroseconds = Math.Round(us(count-1), 4),
      ZeroDeltaSamples = zeros,
      Method = "Native C# Stopwatch/QPC interval-jitter sample; not a DPC/ISR or game-latency benchmark"
    };
  }
}
'@
Add-Type -TypeDefinition $source -Language CSharp
[OptiTimerConsistency]::Run() | ConvertTo-Json -Compress
`;
  const raw = await runPowerShell(script, 60000);
  return JSON.parse(raw);
});

ipcMain.handle('power:create-gaming', async () => {
  if (process.platform !== 'win32') throw new Error('Solo disponible en Windows.');
  const existing = await getPowerSchemes();
  const already = existing.find(x => x.name === 'OPTI TIRUX Gaming (seguro)');
  if (already) {
    if (!ownedPowerSchemes.has(already.guid) && !ownedPowerSchemes.has(already.guid.toLowerCase())) throw new Error('Ya existe un plan con ese nombre que no fue creado por OPTI TIRUX. Renómbralo desde Windows antes de crear otro.');
    return { scheme: already, created: false };
  }
  const { stdout } = await execFileAsync('powercfg.exe', ['/duplicatescheme', 'SCHEME_BALANCED'], { windowsHide: true, timeout: 15000 });
  const guid = (stdout.match(/[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}/) || [])[0];
  if (!guid) throw new Error('Windows no devolvió el identificador del nuevo plan.');
  try {
    await execFileAsync('powercfg.exe', ['/changename', guid, 'OPTI TIRUX Gaming (seguro)', 'Clon de Equilibrado: CPU mínimo 5%, máximo 100% en corriente; 5–85% en batería.'], { windowsHide: true, timeout: 10000 });
    const subgroup = '54533251-82be-4824-96c1-47b60b740d00';
    const min = '893dee8e-2bef-41e0-89c6-b55d0929964c';
    const max = 'bc5038f7-23e0-4960-96da-33abaf5935ec';
    for (const args of [ ['/setacvalueindex', guid, subgroup, min, '5'], ['/setacvalueindex', guid, subgroup, max, '100'], ['/setdcvalueindex', guid, subgroup, min, '5'], ['/setdcvalueindex', guid, subgroup, max, '85'] ]) {
      await execFileAsync('powercfg.exe', args, { windowsHide: true, timeout: 10000 });
    }
    ownedPowerSchemes.add(guid); await saveOwnedPowerSchemes();
    return { scheme: { guid, name: 'OPTI TIRUX Gaming (seguro)', active: false, owned: true }, created: true };
  } catch (err) {
    await execFileAsync('powercfg.exe', ['/delete', guid], { windowsHide: true, timeout: 10000 }).catch(() => {});
    throw err;
  }
});

ipcMain.handle('power:delete-owned', async (_event, guid) => {
  if (typeof guid !== 'string' || !ownedPowerSchemes.has(guid)) throw new Error('Solo se pueden eliminar planes creados y registrados por OPTI TIRUX.');
  const schemes = await getPowerSchemes();
  if (schemes.some(x => x.guid.toLowerCase() === guid.toLowerCase() && x.active)) throw new Error('Activa otro plan antes de eliminar este.');
  await execFileAsync('powercfg.exe', ['/delete', guid], { windowsHide: true, timeout: 10000 });
  ownedPowerSchemes.delete(guid); await saveOwnedPowerSchemes();
  return { deleted: guid };
});

ipcMain.handle('process:priority', async (_event, pid, priority) => {
  if (!Number.isInteger(pid) || pid < 1000) throw new Error('PID no permitido.');
  if (!['BelowNormal', 'Normal', 'AboveNormal'].includes(priority)) throw new Error('Prioridad no permitida.');
  const script = `$id=${pid}; $p=Get-Process -Id $id -ErrorAction Stop; $blocked=@('System','Idle','Registry','csrss','wininit','services','lsass','smss','svchost','winlogon','dwm','fontdrvhost','Secure System','MsMpEng','NisSrv','SecurityHealthService','TrustedInstaller','audiodg','WmiPrvSE','SearchIndexer','WUDFHost'); if($p.Id -le 4 -or $blocked -contains $p.ProcessName){throw 'Proceso protegido.'}; $old=$p.PriorityClass.ToString(); $started=try{$p.StartTime.ToUniversalTime().Ticks}catch{0}; $p.PriorityClass=[System.Diagnostics.ProcessPriorityClass]::${priority}; [pscustomobject]@{Pid=$p.Id;Name=$p.ProcessName;Old=$old;New=$p.PriorityClass.ToString();StartTicks=$started} | ConvertTo-Json -Compress`;
  const raw = await runPowerShell(script, 12000);
  const result = JSON.parse(raw);
  if (!changedPriorities.has(pid)) changedPriorities.set(pid, { name: result.Name, priority: result.Old, startTicks: Number(result.StartTicks) || 0 });
  await persistPriorityBackups();
  return { ...result, changed: true };
});

ipcMain.handle('process:restore-priorities', async () => restorePriorityBackups());

ipcMain.handle('drivers:open-update', async () => {
  if (process.platform !== 'win32') throw new Error('Solo disponible en Windows.');
  await shell.openExternal('ms-settings:windowsupdate');
  return { opened: true };
});
ipcMain.handle('drivers:open-optional', async () => {
  if (process.platform !== 'win32') throw new Error('Solo disponible en Windows.');
  await shell.openExternal('ms-settings:windowsupdate-optionalupdates');
  return { opened: true };
});
ipcMain.handle('startup:open-settings', async () => {
  if (process.platform !== 'win32') throw new Error('Solo disponible en Windows.');
  await shell.openExternal('ms-settings:startupapps');
  return { opened: true };
});

ipcMain.handle('report:export', async () => {
  const dir = path.join(app.getPath('documents'), 'OPTI TIRUX', 'Reports');
  await fs.mkdir(dir, { recursive: true });
  const [system, processes] = await Promise.all([
    si.getStaticData().catch(() => ({})),
    si.processes().catch(() => ({}))
  ]);
  const overview = await (async () => {
    try { return { powerSchemes: await getPowerSchemes(), admin: await isAdmin() }; } catch (e) { return { error: e.message }; }
  })();
  const report = { app: 'OPTI TIRUX', version: app.getVersion(), generatedAt: new Date().toISOString(), system, overview, processCount: processes.all ?? null, processSnapshot: (processes.list || []).slice(0, 150).map(p => ({ pid:p.pid, name:p.name, cpu:p.cpu, memory:p.mem, threads:p.threads })) };
  const file = path.join(dir, `OPTI-TIRUX-report-${new Date().toISOString().replace(/[:.]/g, '-')}.json`);
  await fs.writeFile(file, JSON.stringify(report, null, 2), 'utf8');
  return { file };
});

ipcMain.handle('dpc:start', async () => {
  if (process.platform !== 'win32') throw new Error('Solo disponible en Windows.');
  if (!(await isAdmin())) throw new Error('Para iniciar una captura ETW de DPC/ISR, abre OPTI TIRUX como administrador.');
  const status = await execFileAsync('wpr.exe', ['-status'], { windowsHide: true, timeout: 10000 }).catch(() => ({ stdout: 'unknown' }));
  const statusText = status.stdout || '';
  const noTrace = /no tracing sessions are currently running|no active recording|no hay.*(sesion|grabaci)/i.test(statusText);
  if (noTrace && dpcTraceActive) { dpcTraceActive = false; await clearDpcMarker(); }
  if (dpcTraceActive) throw new Error('Ya hay una captura iniciada por OPTI TIRUX.');
  if (!noTrace && /recording|running|active/i.test(statusText)) throw new Error('WPR ya tiene una captura activa. Detén primero la sesión existente desde la herramienta que la inició.');
  await execFileAsync('wpr.exe', ['-start', 'GeneralProfile', '-filemode'], { windowsHide: true, timeout: 20000 });
  dpcTraceActive = true;
  await saveDpcMarker();
  return { active: true, message: 'Captura ETW iniciada. Reproduce el problema durante 60–120 segundos y después detén la captura.' };
});

ipcMain.handle('dpc:stop', async () => {
  if (!dpcTraceActive) throw new Error('No hay una captura ETW iniciada por OPTI TIRUX.');
  const outDir = path.join(app.getPath('documents'), 'OPTI TIRUX', 'Diagnostics');
  await fs.mkdir(outDir, { recursive: true });
  const outFile = path.join(outDir, `DPC-ISR-${new Date().toISOString().replace(/[:.]/g, '-')}.etl`);
  await execFileAsync('wpr.exe', ['-stop', outFile, 'OPTI TIRUX DPC-ISR trace'], { windowsHide: true, timeout: 60000 });
  dpcTraceActive = false;
  await clearDpcMarker();
  return { active: false, file: outFile, message: 'Captura guardada. Para analizar por módulo/driver se necesita Windows Performance Analyzer (WPA).' };
});

app.whenReady().then(async () => {
  await loadOwnedPowerSchemes();
  await loadPreviousPowerScheme();
  await loadPriorityBackups();
  await loadDpcMarker();
  if (changedPriorities.size) await restorePriorityBackups();
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});
app.on('before-quit', event => {
  if (restoringOnQuit || (changedPriorities.size === 0 && !dpcTraceActive) || process.platform !== 'win32') return;
  event.preventDefault();
  restoringOnQuit = true;
  (async () => {
    if (dpcTraceActive) {
      try {
        const outDir = path.join(app.getPath('documents'), 'OPTI TIRUX', 'Diagnostics');
        await fs.mkdir(outDir, { recursive: true });
        const outFile = path.join(outDir, `DPC-ISR-${new Date().toISOString().replace(/[:.]/g, '-')}-auto.etl`);
        await execFileAsync('wpr.exe', ['-stop', outFile, 'OPTI TIRUX DPC/ISR auto-save on exit'], { windowsHide: true, timeout: 60000 });
        dpcTraceActive = false; await clearDpcMarker();
      } catch {}
    }
    await restorePriorityBackups();
    app.quit();
  })();
});
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
