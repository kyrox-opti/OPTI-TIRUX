@echo off
setlocal EnableExtensions
chcp 65001 >nul 2>&1
title OPTI TIRUX - Instalador automatico
color 0B
cd /d "%~dp0"
set "LOG=%~dp0instalador_log.txt"

echo.
echo  ==============================================================
echo                OPTI TIRUX - INSTALADOR WINDOWS
echo  ==============================================================
echo.
echo  Este asistente prepara las dependencias y crea el instalador.
echo  No aplica optimizaciones de Windows durante la instalacion.
echo  No necesita permisos de administrador para compilar.
echo  Registro de esta ejecucion: %LOG%
echo.

rem --- Comprobaciones previas ---
echo %~dp0| findstr /I /C:"\AppData\Local\Temp\" >nul 2>&1
if not errorlevel 1 (
  echo [ERROR] Parece que ejecutas el BAT desde dentro del ZIP.
  echo         Extrae TODO el ZIP en una carpeta normal ^(p. ej. Escritorio^) y vuelve a abrirlo.
  goto ERROR
)

if not exist "%~dp0package.json" (
  echo [ERROR] No se encuentra package.json junto a este archivo.
  echo         Extrae TODO el ZIP y ejecuta el BAT desde la carpeta OptiTirux-App.
  goto ERROR
)

set "ARCH=%PROCESSOR_ARCHITECTURE%"
if defined PROCESSOR_ARCHITEW6432 set "ARCH=%PROCESSOR_ARCHITEW6432%"
if /I not "%ARCH%"=="AMD64" (
  echo [ERROR] Esta compilacion requiere Windows de 64 bits ^(x64^).
  goto ERROR
)

rem --- Node.js ---
call :CHECK_NODE
if not errorlevel 1 goto BUILD_APP

echo [INFO] Se necesita Node.js 22.12 o superior ^(recomendado LTS^).
where winget >nul 2>&1
if errorlevel 1 (
  echo [ERROR] No se encontro winget. Instala Node.js LTS desde:
  echo         https://nodejs.org/en/download
  echo         Despues cierra esta ventana y vuelve a abrir este archivo.
  start "" "https://nodejs.org/en/download"
  goto ERROR
)

where node >nul 2>&1
if errorlevel 1 (
  echo [INFO] Instalando Node.js LTS...
  winget install --id OpenJS.NodeJS.LTS --exact --source winget --silent --accept-package-agreements --accept-source-agreements
) else (
  echo [INFO] Actualizando Node.js LTS...
  winget upgrade --id OpenJS.NodeJS.LTS --exact --source winget --silent --accept-package-agreements --accept-source-agreements
)

set "PATH=%ProgramFiles%\nodejs;%LOCALAPPDATA%\Programs\nodejs;%APPDATA%\npm;%PATH%"
call :CHECK_NODE
if errorlevel 1 (
  echo [ERROR] Node.js no esta disponible en esta CMD despues de la instalacion.
  echo         Cierra esta ventana, abre una nueva y ejecuta INSTALAR_OPTI_TIRUX.bat otra vez.
  goto ERROR
)

:BUILD_APP
echo.
echo [1/4] Comprobando herramientas...
call node --version
if errorlevel 1 goto ERROR
call npm --version
if errorlevel 1 goto ERROR

echo.
echo [2/4] Instalando dependencias ^(requiere conexion a Internet^)...
call npm install --no-audit --no-fund
if errorlevel 1 goto ERROR

echo.
echo [3/4] Construyendo OPTI TIRUX para Windows x64...
call npm run dist
if errorlevel 1 goto ERROR

echo.
echo [4/4] Buscando el instalador generado...
if not exist "release" (
  echo [ERROR] No se ha creado la carpeta release.
  goto ERROR
)
set "SETUP="
for %%F in ("release\OPTI-TIRUX-Setup-*.exe") do if exist "%%~fF" set "SETUP=%%~fF"
if not defined SETUP (
  echo [ERROR] No se encontro el instalador EXE generado.
  goto ERROR
)

echo.
echo  ==============================================================
echo  [OK] INSTALADOR CREADO
echo  %SETUP%
echo  ==============================================================
echo.
echo Se abrira el instalador. Elige la carpeta y completa la instalacion.
echo Despues encontraras OPTI TIRUX en Inicio y en el Escritorio.
start "OPTI TIRUX Setup" "%SETUP%"
echo.
echo Nota: para capturas DPC/ISR, ejecuta la aplicacion como administrador.
echo Para el uso normal, no hace falta elevar permisos.
pause
exit /b 0

:CHECK_NODE
where node >nul 2>&1
if errorlevel 1 exit /b 1
node -e "const v=process.versions.node.split('.').map(Number); process.exit(v[0] > 22 || (v[0] === 22 && v[1] >= 12) ? 0 : 1)" >nul 2>&1
if errorlevel 1 exit /b 1
where npm >nul 2>&1
if errorlevel 1 exit /b 1
exit /b 0

:ERROR
echo.
echo  [ERROR] El proceso no ha terminado correctamente.
echo  Lee el mensaje anterior. No se han aplicado cambios de optimizacion.
echo.
pause
exit /b 1
