(() => {
  'use strict';

  const api = window.optiTirux;
  if (!api) return;

  let latest = null;
  let processRows = [];
  let tempScan = null;
  let admOverview = null;
  let admPasswordState = null;
  let admUnlocked = false;
  window.lockAdm = () => { admUnlocked = false; };
  let timerConsistency = null;
  let dpcStatus = null;
  let realEvents = [];
  try { const savedEvents = JSON.parse(localStorage.getItem('opti-real-events') || '[]'); if (Array.isArray(savedEvents)) realEvents = savedEvents.slice(0, 100); } catch {}

  const fmtBytes = n => {
    if (!Number.isFinite(n)) return '—';
    const units = ['B', 'KB', 'MB', 'GB', 'TB'];
    let i = 0, v = n;
    while (v >= 1024 && i < units.length - 1) { v /= 1024; i++; }
    return `${v.toFixed(i ? 1 : 0)} ${units[i]}`;
  };
  const pct = n => Number.isFinite(n) ? `${Math.max(0, Math.min(100, n)).toFixed(0)}%` : '—';
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const logEvent = (title, detail) => {
    realEvents.unshift({ title, detail, at: new Date().toLocaleString('es-ES') });
    realEvents = realEvents.slice(0, 100);
    localStorage.setItem('opti-real-events', JSON.stringify(realEvents));
  };
  const toastReal = msg => {
    if (typeof toast === 'function') toast(msg);
  };

  function metricCard(label, value, note) {
    return `<div class="card"><span class="mu">${esc(label)}</span><p style="font-size:25px;font-weight:800;margin:8px 0;color:var(--s)">${esc(value)}</p><span class="mu">${esc(note)}</span></div>`;
  }

  function renderDashboard() {
    const d = latest;
    if (!d) return `<div class="card"><h2>Conectando con Windows…</h2><p class="mu">Esperando la primera lectura del sistema.</p></div>`;
    const gpu = d.gpu?.[0];
    const disk = d.disks?.[0];
    return `
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px">
        <div><h2 style="font-size:24px">Bienvenido a OPTI TIRUX</h2><p class="mu">${esc(d.os)} · ${esc(d.hostname)}</p></div>
        <span class="pill">Lecturas reales de Windows</span>
      </div>
      <div class="card hero">
        <div><h2>OPTIMIZATION STATUS</h2><p class="mu">Monitorización conectada. Los cambios disponibles se aplican de forma individual, con confirmación y opciones de restauración.</p></div>
        <button class="btn" data-real="refresh">Actualizar diagnóstico</button>
      </div>
      <div class="g g4">
        ${metricCard('CPU', pct(d.cpuLoad), d.cpu?.brand || 'Procesador detectado')}
        ${metricCard('RAM', pct(d.memory?.percent), `${fmtBytes(d.memory?.used)} usados de ${fmtBytes(d.memory?.total)}`)}
        ${metricCard('GPU', pct(gpu?.utilization), gpu?.model || 'Uso GPU no disponible')}
        ${metricCard('Disco principal', pct(disk?.use), disk ? `${fmtBytes(disk.used)} / ${fmtBytes(disk.size)}` : 'Sin datos')}
        ${metricCard('Procesos', d.processCount ?? '—', 'Procesos detectados por el sistema')}
        ${metricCard('Temperatura CPU', d.cpuTemperature == null ? 'N/D' : `${d.cpuTemperature.toFixed(0)} °C`, d.cpuTemperature == null ? 'Sensor no expuesto por el equipo' : 'Lectura del sensor')}
        ${metricCard('Núcleos CPU', d.cpu?.physicalCores ?? '—', `${d.cpu?.cores ?? '—'} hilos lógicos`)}
        ${metricCard('Sistema', d.platform === 'win32' ? 'Windows' : d.platform, 'Plataforma detectada')}
      </div>
      <p class="mu" style="margin-top:14px">Última lectura: ${esc(new Date(d.collectedAt).toLocaleTimeString('es-ES'))}. Los sensores no disponibles se muestran como N/D; no se inventan valores.</p>`;
  }

  function renderMonitor() {
    const d = latest;
    if (!d) return '<div class="card">Conectando con sensores…</div>';
    const gpu = d.gpu?.[0];
    return `<div class="g g4">
      ${metricCard('CPU usage', pct(d.cpuLoad), d.cpu?.brand || 'CPU')}
      ${metricCard('GPU usage', pct(gpu?.utilization), gpu?.model || 'GPU')}
      ${metricCard('RAM usage', pct(d.memory?.percent), `${fmtBytes(d.memory?.used)} / ${fmtBytes(d.memory?.total)}`)}
      ${metricCard('CPU temperature', d.cpuTemperature == null ? 'N/D' : `${d.cpuTemperature.toFixed(1)} °C`, 'Sensor disponible según hardware')}
      ${metricCard('GPU temperature', gpu?.temperature == null ? 'N/D' : `${gpu.temperature.toFixed(1)} °C`, gpu?.model || 'GPU')}
      ${metricCard('FPS', 'N/D', 'Requiere integración con PresentMon/CapFrameX')}
      ${metricCard('1% LOW', 'N/D', 'Requiere captura de frametimes')}
      ${metricCard('Frametime', 'N/D', 'No disponible desde el sensor genérico')}
    </div><div class="card" style="margin-top:16px"><h2>Estado de sensores</h2><p class="mu" style="margin-top:8px">Actualización automática cada 3 segundos. Para FPS, 1% lows y frametime conectaremos una fuente de captura dedicada; no se estiman ni simulan.</p></div>`;
  }

  function renderProcesses() {
    return `<div class="card">
      <div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;align-items:center">
        <div><h2>Procesos y subprocesos reales</h2><p class="mu">Lectura de procesos, CPU, RAM e hilos. Puedes ajustar prioridad de procesos de usuario; no se permite Realtime ni tocar procesos críticos.</p></div>
        <div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn bg" data-real="process-restore">Restaurar prioridades</button><button class="btn bg" data-real="process-refresh">Actualizar</button></div>
      </div>
      <input type="search" id="real-process-q" placeholder="Filtrar por nombre o PID" style="max-width:320px;margin:14px 0">
      <div style="overflow:auto"><table><thead><tr><th>Nombre</th><th>CPU %</th><th>RAM %</th><th>PID</th><th>Hilos</th><th>Estado</th><th>Prioridad temporal</th></tr></thead><tbody id="real-process-body">
      ${processRows.map(p => `<tr><td><b>${esc(p.name)}</b></td><td>${p.cpu == null ? '—' : p.cpu.toFixed(1)}</td><td>${p.memory == null ? '—' : p.memory.toFixed(1)}</td><td>${p.pid}</td><td>${p.threads ?? '—'}</td><td>${esc(p.state)}</td><td><select data-priority-choice="${p.pid}" style="width:130px"><option value="">Sin cambio</option><option value="BelowNormal">Baja</option><option value="Normal">Normal</option><option value="AboveNormal">Sobre normal</option></select> <button class="btn bg" data-real="process-priority" data-pid="${p.pid}">Aplicar</button></td></tr>`).join('')}
      </tbody></table></div>
      <p class="mu" style="margin-top:12px">Los cambios originales se guardan localmente y se restauran al cerrar OPTI TIRUX o en el siguiente arranque. Si el proceso termina o cambia la instancia del PID, se omite la restauración. No se cambia afinidad de CPU ni prioridad individual de hilos.</p>
    </div>`;
  }

  function renderCleaner() {
    return `<div class="g g2">
      <div class="card">
        <h2>Temporales del usuario</h2>
        <p class="mu" style="margin:8px 0 14px">Analiza las carpetas temporales del usuario y selecciona únicamente archivos con más de 7 días. No se borran carpetas completas, documentos personales ni archivos recientes.</p>
        <button class="btn" data-real="temp-scan">Analizar archivos temporales</button>
        ${tempScan ? `<div class="row"><span><b>Archivos detectados</b></span><b>${tempScan.count}</b></div><div class="row"><span><b>Espacio recuperable estimado</b></span><b>${fmtBytes(tempScan.bytes)}</b></div><div class="row"><span><b>Antigüedad mínima</b></span><b>7 días</b></div>${tempScan.capped ? '<p class="mu">Se alcanzó el límite de exploración; el resultado puede estar incompleto.</p>' : ''}<button class="btn" style="margin-top:12px" data-real="temp-clean" ${tempScan.count ? '' : 'disabled'}>Limpiar archivos seleccionados</button>` : '<p class="mu" style="margin-top:12px">Todavía no se ha realizado ningún análisis.</p>'}
      </div>
      <div class="card">
        <h2>Protección de limpieza</h2>
        <div class="row"><span><b>Archivos personales</b></span><span class="tag Bajo">Protegidos</span></div>
        <div class="row"><span><b>Archivos recientes (&lt; 7 días)</b></span><span class="tag Bajo">Se conservan</span></div>
        <div class="row"><span><b>Carpetas y enlaces simbólicos</b></span><span class="tag Bajo">No se eliminan</span></div>
        <div class="row"><span><b>Archivos en uso</b></span><span class="tag Medio">Se omiten</span></div>
        <p class="mu" style="margin-top:12px">La eliminación de temporales no se puede deshacer desde Restore Center. Se muestra una vista previa antes de borrar.</p>
      </div>
    </div>`;
  }

  function renderOptimizer() {
    return `<div class="card hero"><div><h2>Perfiles de optimización</h2><p class="mu">Perfiles diferenciados por nivel de intervención. Los ajustes de Windows se muestran y aplican solo cuando existe una operación real, compatible y reversible.</p></div><span class="tag Medio">Configuración segura</span></div>
    <div class="g g2">
      ${[['BAJO','Estabilidad','Activa Equilibrado: comportamiento conservador.'],['MEDIO','Equilibrio','Usa Alto rendimiento si existe; si no, conserva Equilibrado.'],['ALTO','Gaming','Crea y activa un clon seguro de Equilibrado para jugar conectado.'],['ADM','Avanzado','Abre el laboratorio avanzado de Windows.']].map(([n,t,d])=>`<div class="card"><h2>${n}</h2><p style="margin:6px 0;color:var(--s);font-weight:700">${t}</p><p class="mu">${d}</p><button class="btn bg" style="margin-top:14px" data-real="profile-apply" data-profile="${n}">${n==='ADM'?'Abrir ADM':'Aplicar perfil (energía)'}</button></div>`).join('')}
    </div>
    <div class="card" style="margin-top:16px"><h2>Principios del motor</h2><p class="mu" style="margin-top:8px">No se desactivan Defender, Firewall, VBS, HVCI ni servicios esenciales. No se fuerzan prioridades de todos los procesos, no se cambian voltajes ni límites térmicos y no se aplican tweaks de registro sin copia y reversión verificables.</p></div>`;
  }

  function renderGaming() {
    return `<div class="card hero"><div><h2>Gaming Mode · ${esc(typeof gm !== 'undefined' ? gm : 'Fortnite')}</h2><p class="mu">Preparación guiada para jugar. No mata procesos ni cambia servicios automáticamente.</p></div><button class="btn" data-real="gaming-prep">Preparar sesión</button></div>
    <div class="g g2">
      <div class="card"><h2>Antes de jugar</h2><div class="row"><span><b>Conectar el cargador</b><span class="mu">En portátiles, evita depender solo de batería.</span></span></div><div class="row"><span><b>Guardar el trabajo</b><span class="mu">Antes de cerrar aplicaciones manualmente.</span></span></div><div class="row"><span><b>Comprobar actualizaciones</b><span class="mu">Evita instalaciones o reinicios durante la partida.</span></span></div></div>
      <div class="card"><h2>Acciones automáticas</h2><p class="mu" style="margin-top:8px">Todavía no hay ninguna acción destructiva habilitada. La futura gestión de aplicaciones usará una lista de exclusión y pedirá confirmación antes de cerrar algo.</p></div>
    </div>`;
  }

  function renderAdm() {
    if (!admUnlocked) {
      const configured = admPasswordState?.configured;
      return `<div class="card" style="max-width:520px;margin:34px auto"><h2>ADM · Zona privada</h2><p class="mu" style="margin:8px 0 16px">${configured ? 'Introduce tu contraseña local para abrir el laboratorio avanzado.' : 'Crea una contraseña local para proteger ADM. Se guarda como hash con salt; OPTI TIRUX no almacena la contraseña en texto.'}</p><input id="adm-password" type="password" autocomplete="new-password" placeholder="${configured ? 'Contraseña ADM' : 'Nueva contraseña (mínimo 10 caracteres)'}" style="width:100%;margin-bottom:12px"><button class="btn" data-real="${configured ? 'adm-unlock' : 'adm-password-create'}">${configured ? 'Desbloquear ADM' : 'Crear contraseña ADM'}</button><p class="mu" style="margin-top:10px">La contraseña se guarda solo en este perfil de Windows. Si la olvidas, puedes restablecerla eliminando el archivo de credenciales desde la carpeta de datos de la aplicación.</p></div>`;
    }
    const d = latest, a = admOverview;
    const schemes = a?.schemes || [];
    const drivers = a?.drivers || [];
    const issues = a?.problemDevices || [];
    const startup = a?.startup || [];
    const timer = a?.timerResolution || {};
    return `<div class="card hero"><div><h2>ADM · Advanced Windows Lab</h2><p class="mu">Centro avanzado real de diagnóstico y ajustes controlados. Las funciones que requieren herramientas o permisos adicionales se identifican claramente.</p></div><div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn bg" data-real="adm-lock">Bloquear ADM</button><button class="btn" data-real="adm-refresh">Analizar Windows</button></div></div>
    <div class="g g4">
      ${metricCard('CPU', pct(d?.cpuLoad), d?.cpu?.brand || 'Procesador')}
      ${metricCard('RAM', pct(d?.memory?.percent), `${fmtBytes(d?.memory?.used)} / ${fmtBytes(d?.memory?.total)}`)}
      ${metricCard('Drivers', drivers.length ? drivers.length : 'N/D', 'Controladores PnP enumerados')}
      ${metricCard('Dispositivos con incidencias', issues.length, 'Estado PnP distinto de OK')}
    </div>
    <div class="g g2" style="margin-top:16px">
      <div class="card"><h2>Windows y permisos</h2>
        <div class="row"><b>Sistema</b><span class="mu">${esc(d?.os || 'N/D')}</span></div>
        <div class="row"><b>Ejecutando como administrador</b><span class="tag ${a?.admin?'Bajo':'Medio'}">${a ? (a.admin?'Sí':'No') : 'Sin analizar'}</span></div>
        <div class="row"><b>Procesos</b><span class="mu">${d?.processCount ?? 'N/D'}</span></div>
        <div class="row"><b>CPU / hilos</b><span class="mu">${d?.cpu?.physicalCores ?? '—'} / ${d?.cpu?.cores ?? '—'}</span></div>
        <p class="mu" style="margin-top:10px">El panel no detiene servicios ni termina procesos esenciales. Los subprocesos se muestran como dato de diagnóstico; no se modifican en bloque.</p>
      </div>
      <div class="card"><h2>Planes de energía reales</h2>
        ${schemes.length ? schemes.map(x=>`<div class="row"><span><b>${esc(x.name)}</b><span class="mu">${esc(x.guid)}</span></span><span style="display:flex;gap:6px;align-items:center">${x.active?'<span class="tag Bajo">Activo</span>':`<button class="btn bg" data-real="power-set" data-guid="${esc(x.guid)}">Activar</button>`}${x.owned?`<button class="btn bg" data-real="power-delete" data-guid="${esc(x.guid)}">Eliminar</button>`:''}</span></div>`).join('') : '<p class="mu">Pulsa Analizar Windows para consultar powercfg.</p>'}
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px"><button class="btn" data-real="power-create-gaming">Crear plan Gaming OPTI</button><button class="btn bg" data-real="power-restore">Restaurar plan anterior</button></div>
        <p class="mu" style="margin-top:8px">Se usan planes que Windows ya tiene instalados. No se fuerza Ultimate Performance ni se cambia automáticamente el perfil del portátil.</p>
      </div>
      <div class="card"><h2>Drivers y dispositivos</h2>
        <div class="row"><b>Drivers detectados</b><span class="mu">${drivers.length}</span></div>
        <div class="row"><b>Dispositivos con estado anómalo</b><span class="mu">${issues.length}</span></div>
        ${issues.slice(0,12).map(x=>`<div class="row"><span><b>${esc(x.FriendlyName || 'Dispositivo')}</b><span class="mu">${esc(x.Class || '')} · ${esc(x.InstanceId || '')}</span></span><span class="tag Medio">${esc(x.Status || 'Error')}</span></div>`).join('') || '<p class="mu" style="margin-top:8px">No se han detectado dispositivos con estado distinto de OK, o falta ejecutar el análisis.</p>'}
        <p class="mu" style="margin-top:10px">Inventario de drivers firmados y versiones. Para buscar paquetes nuevos se abre Windows Update; revisa también las actualizaciones opcionales. No se instala un controlador a ciegas.</p><div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn bg" data-real="driver-update">Abrir Windows Update</button><button class="btn bg" data-real="driver-optional">Ver drivers opcionales</button></div>
        <details style="margin-top:10px"><summary>Ver inventario de drivers (primeros 60)</summary>${drivers.slice(0,60).map(x=>`<div class="row"><span><b>${esc(x.DeviceName || 'Dispositivo')}</b><span class="mu">${esc(x.Manufacturer || '')} · ${esc(x.InfName || '')} · ${esc(x.DriverDate || 'fecha N/D')}</span></span><span class="mu">${esc(x.DriverVersion || 'N/D')}</span></div>`).join('')}</details>
      </div>
      <div class="card"><h2>Inicio y segundo plano</h2>
        <div class="row"><b>Entradas de inicio detectadas</b><span class="mu">${startup.length}</span></div>
        ${startup.slice(0,18).map(x=>`<div class="row"><span><b>${esc(x.Name || 'Entrada')}</b><span class="mu">${esc(x.Location || '')} · ${esc(x.User || '')}</span></span></div>`).join('') || '<p class="mu">Pulsa Analizar Windows para consultar entradas de inicio.</p>'}
        <p class="mu" style="margin-top:8px">Solo inventario. Para activar o desactivar entradas, abre la página nativa de aplicaciones de inicio y revisa el editor y fabricante antes de cambiar nada.</p><button class="btn bg" data-real="startup-settings">Abrir aplicaciones de inicio</button>
      </div>
      <div class="card"><h2>Timer Consistency</h2>
        <div class="row"><b>Resolución actual</b><span class="mu">${Number.isFinite(timer.CurrentMs) ? `${timer.CurrentMs.toFixed(4)} ms` : 'N/D'}</span></div><div class="row"><b>Rango soportado (mín. / máx.)</b><span class="mu">${Number.isFinite(timer.Minimum100ns) && Number.isFinite(timer.Maximum100ns) ? `${(timer.Minimum100ns/10000).toFixed(4)} / ${(timer.Maximum100ns/10000).toFixed(4)} ms` : 'N/D'}</span></div>
        <p class="mu" style="margin:8px 0">La prueba mide variación de intervalos con Stopwatch/QPC. No cambia la resolución del timer ni demuestra por sí sola latencia de juego.</p>
        <button class="btn" data-real="timer-test">Ejecutar Timer Consistency</button>
        ${timerConsistency ? `<div class="row"><b>Mediana</b><span class="mu">${timerConsistency.MedianMicroseconds} µs</span></div><div class="row"><b>P95 / P99</b><span class="mu">${timerConsistency.P95Microseconds} / ${timerConsistency.P99Microseconds} µs</span></div><div class="row"><b>Máximo</b><span class="mu">${timerConsistency.MaxMicroseconds} µs</span></div><p class="mu">${esc(timerConsistency.Method)}</p><div class="row"><b>Muestras con delta cero</b><span class="mu">${timerConsistency.ZeroDeltaSamples ?? 'N/D'}</span></div><p class="mu">Ejecuta en reposo y repite durante carga para comparar. Es una prueba QPC, no una puntuación de calidad del PC.</p>` : ''}
      </div>
      <div class="card"><h2>DPC / ISR latency</h2>
        <div class="row"><b>Windows Performance Recorder</b><span class="tag ${a?.tools?.wpr?'Bajo':'Medio'}">${a ? (a.tools?.wpr?'Disponible':'No encontrado') : 'Sin analizar'}</span></div>
        <div class="row"><b>Windows Performance Analyzer</b><span class="tag ${a?.tools?.wpa?'Bajo':'Medio'}">${a ? (a.tools?.wpa?'Disponible':'No encontrado') : 'Sin analizar'}</span></div>
        <div class="row"><b>LatencyMon</b><span class="tag ${a?.tools?.latencyMon?'Bajo':'Medio'}">${a ? (a.tools?.latencyMon?'Disponible':'No encontrado') : 'No detectado'}</span></div>
        <p class="mu" style="margin:8px 0">DPC e ISR se estudian mediante trazas ETW. La captura no identifica por sí sola al culpable; el análisis por driver requiere WPA o una herramienta especializada.</p>
        ${a?.dpcTraceActive ? '<button class="btn" data-real="dpc-stop">Detener y guardar captura ETL</button>' : '<button class="btn" data-real="dpc-start">Iniciar captura ETW DPC/ISR</button>'}
        ${dpcStatus ? `<p class="mu" style="margin-top:8px">${esc(dpcStatus)}</p>` : ''}
      </div>
      <div class="card"><h2>Procesos y subprocesos</h2><p class="mu">Listado real en Process Manager. Permite cambiar temporalmente prioridad de procesos de usuario (sin Realtime ni procesos protegidos) y restaurarla. No modifica prioridades de hilos individuales.</p><button class="btn bg" data-go="pm">Abrir Process Manager</button></div>
      <div class="card"><h2>Informe técnico</h2><p class="mu" style="margin:8px 0">Exporta un informe local JSON con inventario del equipo, planes de energía y una muestra de procesos. No se envía a ningún servidor.</p><button class="btn bg" data-real="report-export">Exportar informe</button></div>
      <div class="card"><h2>Historial ADM</h2>${realEvents.slice(0,8).map(x=>`<div class="row"><span><b>${esc(x.title)}</b><span class="mu">${esc(x.detail)}</span></span><span class="mu">${esc(x.at)}</span></div>`).join('') || '<p class="mu">Todavía no hay operaciones.</p>'}</div>
    </div>`;
  }

  function renderRestore() {
    return `<div class="card"><h2>Historial de OPTI TIRUX</h2><p class="mu" style="margin:6px 0 12px">Registro local de diagnósticos y limpiezas reales. Las eliminaciones de archivos no son reversibles.</p>
      ${realEvents.length ? realEvents.map(x=>`<div class="row"><span><b>${esc(x.title)}</b><span class="mu">${esc(x.detail)}</span></span><span class="mu">${esc(x.at)}</span></div>`).join('') : '<div class="em"><h3>Sin actividad registrada</h3><p>Las operaciones reales aparecerán aquí.</p></div>'}
      <button class="btn bg" data-real="export-log">Exportar historial</button>
    </div>`;
  }

  // Override the original demo views with live Windows-connected views.
  V.dash = renderDashboard;
  V.mon = renderMonitor;
  V.pm = renderProcesses;
  V.cl = renderCleaner;
  V.opt = renderOptimizer;
  V.game = renderGaming;
  V.adm = renderAdm;
  V.rc = renderRestore;
  V.pf = renderOptimizer;
  V.set = () => `<div class="card"><h2>Configuración de OPTI TIRUX</h2><p class="mu" style="margin:8px 0 14px">Las preferencias de esta aplicación se guardan localmente. Los ajustes del sistema se gestionan desde los módulos reales, no desde interruptores decorativos.</p><div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn bg" data-real="driver-update">Windows Update</button><button class="btn bg" data-real="startup-settings">Aplicaciones de inicio</button><button class="btn" data-go="adm">Abrir ADM</button></div><p class="mu" style="margin-top:14px">Versión 1.2.0 · Sin telemetría ni cuenta en la nube en esta compilación.</p></div>`;
  V.com = () => `<div class="card"><h2>Comunidad</h2><p class="mu" style="margin-top:8px">La comunidad online, chat y sincronización todavía no están conectados. Esta versión no simula publicaciones ni cuentas sociales.</p></div>`;
  V.me = () => `<div class="card"><h2>Perfil local</h2><p class="mu" style="margin-top:8px">OPTI TIRUX guarda las preferencias y perfiles en este equipo. No se necesita crear una cuenta ni enviar datos a un servidor.</p></div>`;

  async function refreshSystem() {
    try {
      latest = await api.getSystemInfo();
      const pill = document.querySelector('.top .pill');
      if (pill) pill.textContent = 'Conectado · lecturas locales';
      if (['dash','mon'].includes(cur)) re();
    } catch (err) {
      toastReal(`No se pudo leer el sistema: ${err.message}`);
    }
  }

  async function refreshProcesses() {
    try {
      processRows = await api.getProcesses();
      renderProcessRows();
    } catch (err) { toastReal(`Error leyendo procesos: ${err.message}`); }
  }

  function renderProcessRows() {
    const body = document.getElementById('real-process-body');
    if (!body) return;
    const q = (document.getElementById('real-process-q')?.value || '').toLowerCase();
    body.innerHTML = processRows.filter(p => p.name.toLowerCase().includes(q) || String(p.pid).includes(q))
      .map(p => `<tr><td><b>${esc(p.name)}</b></td><td>${p.cpu == null ? '—' : p.cpu.toFixed(1)}</td><td>${p.memory == null ? '—' : p.memory.toFixed(1)}</td><td>${p.pid}</td><td>${p.threads ?? '—'}</td><td>${esc(p.state)}</td><td><select data-priority-choice="${p.pid}" style="width:130px"><option value="">Sin cambio</option><option value="BelowNormal">Baja</option><option value="Normal">Normal</option><option value="AboveNormal">Sobre normal</option></select> <button class="btn bg" data-real="process-priority" data-pid="${p.pid}">Aplicar</button></td></tr>`).join('');
  }

  document.addEventListener('click', async e => {
    const b = e.target.closest('[data-real]');
    if (!b) return;
    const action = b.dataset.real;
    if (action === 'adm-password-create') {
      const password = document.getElementById('adm-password')?.value || '';
      try { await api.setAdmPassword(password); admPasswordState = { configured: true }; admUnlocked = true; await refreshSystem(); admOverview = await api.getAdmOverview(); logEvent('Contraseña ADM creada', 'Credencial local protegida'); re(); toastReal('ADM protegido y desbloqueado.'); }
      catch (err) { toastReal(`No se pudo crear la contraseña: ${err.message}`); }
    }
    if (action === 'adm-unlock') {
      const password = document.getElementById('adm-password')?.value || '';
      try { const r = await api.verifyAdmPassword(password); if (!r.valid) { toastReal('Contraseña incorrecta.'); return; } admUnlocked = true; await refreshSystem(); admOverview = await api.getAdmOverview(); logEvent('ADM desbloqueado', 'Acceso local verificado'); re(); }
      catch (err) { toastReal(`No se pudo desbloquear ADM: ${err.message}`); }
    }
    if (action === 'adm-lock') { admUnlocked = false; re(); }
    if (action === 'adm-refresh') {
      b.disabled = true;
      try { await refreshSystem(); admOverview = await api.getAdmOverview(); logEvent('Diagnóstico ADM', `${admOverview.drivers.length} drivers · ${admOverview.problemDevices.length} dispositivos con incidencias · ${admOverview.schemes.length} planes de energía`); re(); }
      catch (err) { toastReal(`Error en diagnóstico ADM: ${err.message}`); }
    }
    if (action === 'power-set') {
      const guid = b.dataset.guid;
      const plan = admOverview?.schemes?.find(x => x.guid === guid);
      modal(`<h2>Activar plan de energía</h2><p class="mu" style="margin-top:8px">Windows cambiará al plan «${esc(plan?.name || guid)}». El plan anterior quedará guardado para restaurarlo incluso después de reiniciar la aplicación.</p>`, 1, async () => {
        try { const r = await api.setPowerPlan(guid); logEvent('Plan de energía activado', r.active.name); admOverview = await api.getAdmOverview(); toastReal(`Plan activado: ${r.active.name}`); re(); }
        catch (err) { toastReal(`No se pudo activar el plan: ${err.message}`); }
      }, 'Activar plan');
    }
    if (action === 'power-restore') {
      try { const r = await api.restorePowerPlan(); admOverview = await api.getAdmOverview(); logEvent('Plan de energía restaurado', r.restored); toastReal('Se restauró el plan anterior.'); re(); }
      catch (err) { toastReal(err.message); }
    }
    if (action === 'timer-test') {
      b.disabled = true; toastReal('Ejecutando prueba Timer Consistency…');
      try { timerConsistency = await api.runTimerConsistency(); logEvent('Timer Consistency', `P95 ${timerConsistency.P95Microseconds} µs · P99 ${timerConsistency.P99Microseconds} µs`); re(); }
      catch (err) { toastReal(`La prueba falló: ${err.message}`); }
    }
    if (action === 'dpc-start') {
      try { const r = await api.startDpcTrace(); dpcStatus = r.message; admOverview = await api.getAdmOverview(); logEvent('Captura DPC/ISR iniciada', r.message); re(); }
      catch (err) { toastReal(`No se pudo iniciar la captura: ${err.message}`); }
    }
    if (action === 'dpc-stop') {
      try { const r = await api.stopDpcTrace(); dpcStatus = `${r.message} Archivo: ${r.file}`; admOverview = await api.getAdmOverview(); logEvent('Captura DPC/ISR guardada', r.file); re(); }
      catch (err) { toastReal(`No se pudo detener la captura: ${err.message}`); }
    }
    if (action === 'refresh') await refreshSystem();
    if (action === 'process-refresh') await refreshProcesses();
    if (action === 'temp-scan') {
      b.disabled = true;
      try { tempScan = await api.scanTemp(); re(); }
      catch (err) { toastReal(`No se pudo analizar temporales: ${err.message}`); }
    }
    if (action === 'temp-clean') {
      modal(`<h2>Confirmar limpieza</h2><p class="mu" style="margin-top:8px">Se eliminarán ${tempScan?.count || 0} archivos temporales de más de 7 días (aprox. ${fmtBytes(tempScan?.bytes || 0)}). Esta operación no se puede deshacer.</p>`, 1, async () => {
        try {
          const result = await api.cleanTemp();
          tempScan = null;
          logEvent('Limpieza de temporales', `${result.deleted} archivos eliminados · ${fmtBytes(result.bytes)} · ${result.skipped} omitidos`);
          toastReal(`Limpieza terminada: ${result.deleted} archivos · ${fmtBytes(result.bytes)}`);
          re();
        } catch (err) { toastReal(`La limpieza falló: ${err.message}`); }
      }, 'Eliminar archivos');
    }
    if (action === 'power-create-gaming') {
      b.disabled = true;
      try { const r = await api.createGamingPowerPlan(); admOverview = await api.getAdmOverview(); logEvent('Plan Gaming creado', r.scheme.guid); toastReal(r.created ? 'Plan Gaming OPTI creado. Actívalo cuando estés conectado a corriente.' : 'El plan Gaming OPTI ya existía.'); re(); }
      catch (err) { toastReal(`No se pudo crear el plan: ${err.message}`); }
    }
    if (action === 'power-delete') {
      const guid = b.dataset.guid;
      modal('<h2>Eliminar plan OPTI TIRUX</h2><p class="mu" style="margin-top:8px">Solo se eliminará el plan que esta aplicación creó y registró. No se tocarán los planes originales de Windows.</p>', 1, async () => {
        try { await api.deleteOwnedPowerPlan(guid); admOverview = await api.getAdmOverview(); logEvent('Plan Gaming eliminado', guid); toastReal('Plan eliminado.'); re(); }
        catch (err) { toastReal(`No se pudo eliminar: ${err.message}`); }
      }, 'Eliminar plan');
    }
    if (action === 'process-priority') {
      const pid = Number(b.dataset.pid);
      const select = document.querySelector(`[data-priority-choice="${pid}"]`);
      const priority = select?.value;
      if (!priority) { toastReal('Selecciona una prioridad primero.'); return; }
      const proc = processRows.find(x => x.pid === pid);
      modal(`<h2>Cambiar prioridad de proceso</h2><p class="mu" style="margin-top:8px">Se cambiará temporalmente «${esc(proc?.name || pid)}» (PID ${pid}) a ${esc(priority)}. No uses prioridad elevada en procesos que no sean el juego; el cambio se restaurará al cerrar la aplicación.</p>`, 1, async () => {
        try { const r = await api.setProcessPriority(pid, priority); logEvent('Prioridad de proceso', `${r.Name} (${pid}): ${r.Old} → ${r.New}`); toastReal(`Prioridad cambiada: ${r.Name}`); }
        catch (err) { toastReal(`No se pudo cambiar la prioridad: ${err.message}`); }
      }, 'Aplicar temporalmente');
    }
    if (action === 'process-restore') {
      try { const r = await api.restoreProcessPriorities(); logEvent('Restaurar prioridades', `${r.restored.length} restauradas · ${r.failures.length} omitidas`); toastReal(`${r.restored.length} prioridades restauradas; ${r.failures.length} omitidas.`); }
      catch (err) { toastReal(`No se pudieron restaurar prioridades: ${err.message}`); }
    }
    if (action === 'driver-update') {
      try { await api.openDriverUpdates(); logEvent('Windows Update abierto', 'Comprobación de actualizaciones de controladores'); }
      catch (err) { toastReal(`No se pudo abrir Windows Update: ${err.message}`); }
    }
    if (action === 'driver-optional') {
      try { await api.openOptionalDriverUpdates(); logEvent('Drivers opcionales abiertos', 'Windows Update'); }
      catch (err) { toastReal(`No se pudo abrir la sección: ${err.message}`); }
    }
    if (action === 'startup-settings') {
      try { await api.openStartupSettings(); logEvent('Aplicaciones de inicio abiertas', 'Gestión nativa de Windows'); }
      catch (err) { toastReal(`No se pudo abrir la configuración: ${err.message}`); }
    }
    if (action === 'report-export') {
      try { const r = await api.exportReport(); logEvent('Informe técnico exportado', r.file); toastReal(`Informe guardado: ${r.file}`); }
      catch (err) { toastReal(`No se pudo exportar el informe: ${err.message}`); }
    }
    if (action === 'profile-apply') {
      const profile = b.dataset.profile;
      if (profile === 'ADM') { cur = 'adm'; show(); return; }
      try {
        let schemes = admOverview?.schemes;
        if (!schemes) { admOverview = await api.getAdmOverview(); schemes = admOverview.schemes; }
        const balanced = schemes.find(x => x.guid.toLowerCase() === '381b4222-f694-41f0-9685-ff5bb260df2e');
        const high = schemes.find(x => x.guid.toLowerCase() === '8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c');
        let target = profile === 'BAJO' ? balanced : profile === 'MEDIO' ? (high || balanced) : null;
        if (profile === 'ALTO') {
          const created = await api.createGamingPowerPlan();
          target = created.scheme;
        }
        if (!target) throw new Error('No se encontró un plan compatible de Windows.');
        const r = await api.setPowerPlan(target.guid);
        logEvent(`Perfil ${profile} aplicado`, `Plan energético: ${r.active.name}`);
        admOverview = await api.getAdmOverview();
        toastReal(`Perfil ${profile}: ${r.active.name}. Solo se modificó el plan energético.`); re();
      } catch (err) { toastReal(`No se pudo aplicar el perfil: ${err.message}`); }
    }
    if (action === 'profile-info') {
      modal(`<h2>Perfil ${esc(b.dataset.profile)}</h2><p class="mu" style="margin-top:8px">Los perfiles BAJO, MEDIO y ALTO aplican únicamente un plan energético real de Windows. Para cambios avanzados, usa ADM y revisa cada operación por separado. No se alteran servicios, seguridad ni drivers automáticamente.</p>`, 0);
    }
    if (action === 'gaming-prep') {
      modal(`<h2>Preparación para gaming</h2><p class="mu" style="margin-top:8px">Conecta el cargador, guarda documentos y cierra manualmente aplicaciones que no necesites. En esta versión no se termina ningún proceso ni se alteran servicios o protecciones.</p>`, 0);
      logEvent('Preparación gaming consultada', 'Se mostró la lista segura de preparación.');
    }
    if (action === 'export-log') {
      const blob = new Blob([JSON.stringify(realEvents, null, 2)], {type:'application/json'});
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a'); a.href = url; a.download = 'opti-tirux-historial.json'; a.click();
      URL.revokeObjectURL(url);
    }
  }, true);

  document.addEventListener('input', e => {
    if (e.target.id === 'real-process-q') renderProcessRows();
  });
  document.addEventListener('keydown', e => {
    if (e.key === 'Enter' && e.target.id === 'adm-password') document.querySelector('[data-real=adm-unlock], [data-real=adm-password-create]')?.click();
  });

  // Stop legacy demo actions that claim to change Windows or kill processes.
  document.addEventListener('click', e => {
    const b = e.target.closest('[data-a]');
    if (!b) return;
    const blocked = new Set(['scan','opt','ap','prep','clean','kill','adm','admopt','rall','rev','react','reactall','quit']);
    if (blocked.has(b.dataset.a)) {
      e.preventDefault();
      e.stopImmediatePropagation();
      if (b.dataset.a === 'scan') refreshSystem().then(() => {
        modal(`<h2>Diagnóstico real completado</h2><p class="mu" style="margin-top:8px">Se han consultado CPU, memoria, GPU, discos y procesos. Mira Dashboard, Monitor y Process Manager para ver las lecturas disponibles.</p>`, 0);
        logEvent('Diagnóstico del sistema', 'Lectura de hardware y recursos completada.');
      });
      else if (b.dataset.a === 'opt' || b.dataset.a === 'ap' || b.dataset.a === 'admopt') {
        modal(`<h2>Optimización todavía no aplicada</h2><p class="mu" style="margin-top:8px">No voy a fingir que se han cambiado ajustes de Windows. El motor se implementará ajuste por ajuste, con comprobación del estado actual, copia de seguridad y reversión cuando sea viable.</p>`, 0);
      } else if (b.dataset.a === 'prep') {
        modal(`<h2>Preparación gaming</h2><p class="mu" style="margin-top:8px">No se cerrarán procesos automáticamente en esta versión. Usa la lista de preparación y guarda tu trabajo antes de cerrar aplicaciones.</p>`, 0);
      } else if (b.dataset.a === 'clean') {
        modal(`<h2>Usa el análisis real de temporales</h2><p class="mu" style="margin-top:8px">La limpieza de ejemplo ha sido deshabilitada. Pulsa “Analizar archivos temporales” para obtener una vista previa real.</p>`, 0);
      } else {
        modal(`<h2>Acción protegida</h2><p class="mu" style="margin-top:8px">Esta acción no está disponible todavía. Se habilitará cuando tenga una implementación segura y verificable.</p>`, 0);
      }
    }
  }, true);

  // Disable fake login/admin overlays; this local desktop build has no cloud account system.
  const loginOverlay = document.getElementById('lo');
  const adminOverlay = document.getElementById('ad');
  if (loginOverlay) loginOverlay.style.display = 'none';
  if (adminOverlay) adminOverlay.style.display = 'none';
  if (typeof user !== 'undefined') user = 'Local';
  if (typeof guest !== 'undefined') guest = false;
  const statusPill = document.querySelector('.top .pill');
  if (statusPill) statusPill.textContent = 'Conectando con Windows…';

  // Remove fictional starter profiles from the HTML demo.
  if (typeof PR !== 'undefined') PR.splice(0, PR.length, ['Uso diario', 'LOW', 'Ninguno']);

  // Restore local profile choices; no account or password is stored.
  try {
    const saved = JSON.parse(localStorage.getItem('opti-tirux-state') || '{}');
    if (Array.isArray(saved.profiles) && typeof PR !== 'undefined') PR.splice(0, PR.length, ...saved.profiles);
    if (saved.game && typeof gm !== 'undefined') gm = saved.game;
    if (saved.active && typeof active !== 'undefined') active = saved.active;
    if (saved.activeName && typeof apn !== 'undefined') apn = saved.activeName;
  } catch {}

  setTimeout(() => {
    if (typeof show === 'function') show();
    refreshSystem();
    refreshProcesses();
  }, 0);

  setInterval(() => {
    if (typeof PR !== 'undefined') {
      localStorage.setItem('opti-tirux-state', JSON.stringify({
        profiles: PR, game: typeof gm !== 'undefined' ? gm : 'Fortnite',
        active: typeof active !== 'undefined' ? active : 'LOW',
        activeName: typeof apn !== 'undefined' ? apn : 'Uso diario'
      }));
    }
    refreshSystem();
  }, 3000);

  // Re-render live process table when entering the page.
  const originalShow = window.show;
  if (typeof originalShow === 'function') {
    window.show = function() {
      originalShow();
      if (cur === 'pm') setTimeout(refreshProcesses, 380);
      if (cur === 'adm') setTimeout(async () => { try { admPasswordState = await api.getAdmPasswordStatus(); if (admUnlocked && !admOverview) admOverview = await api.getAdmOverview(); re(); } catch (err) { toastReal(`ADM: ${err.message}`); } }, 380);
    };
  }
})();
