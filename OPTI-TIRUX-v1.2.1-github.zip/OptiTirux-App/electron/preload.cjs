const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('optiTirux', Object.freeze({
  getSystemInfo: () => ipcRenderer.invoke('system:info'),
  getProcesses: () => ipcRenderer.invoke('processes:list'),
  scanTemp: () => ipcRenderer.invoke('temp:scan'),
  cleanTemp: () => ipcRenderer.invoke('temp:clean'),
  getAdmOverview: () => ipcRenderer.invoke('adm:overview'),
  getAdmPasswordStatus: () => ipcRenderer.invoke('adm:password-status'),
  setAdmPassword: password => ipcRenderer.invoke('adm:password-set', password),
  verifyAdmPassword: password => ipcRenderer.invoke('adm:password-verify', password),
  setPowerPlan: guid => ipcRenderer.invoke('power:set', guid),
  restorePowerPlan: () => ipcRenderer.invoke('power:restore'),
  createGamingPowerPlan: () => ipcRenderer.invoke('power:create-gaming'),
  deleteOwnedPowerPlan: guid => ipcRenderer.invoke('power:delete-owned', guid),
  setProcessPriority: (pid, priority) => ipcRenderer.invoke('process:priority', pid, priority),
  restoreProcessPriorities: () => ipcRenderer.invoke('process:restore-priorities'),
  openDriverUpdates: () => ipcRenderer.invoke('drivers:open-update'),
  openOptionalDriverUpdates: () => ipcRenderer.invoke('drivers:open-optional'),
  openStartupSettings: () => ipcRenderer.invoke('startup:open-settings'),
  exportReport: () => ipcRenderer.invoke('report:export'),
  runTimerConsistency: () => ipcRenderer.invoke('timer:consistency'),
  startDpcTrace: () => ipcRenderer.invoke('dpc:start'),
  stopDpcTrace: () => ipcRenderer.invoke('dpc:stop')
}));
