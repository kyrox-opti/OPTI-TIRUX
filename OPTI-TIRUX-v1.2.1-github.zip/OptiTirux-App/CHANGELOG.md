# Cambios

## 1.2.0

- Actualizado el runtime a Electron 45.3.x y las herramientas de empaquetado a electron-builder 26.18.x.
- Actualizada la biblioteca de inventario del sistema a systeminformation 5.33.x.
- Añadida protección local de ADM con hash scrypt y salt aleatorio.
- Añadido cambio de prioridad de proceso con lista de exclusión, validación de PID/instancia y restauración al cerrar o al siguiente arranque.
- Añadida creación de un plan energético Gaming clonado desde Equilibrado, con valores conservadores AC/DC y eliminación limitada al plan creado por la aplicación.
- Persistencia del plan energético anterior para restaurarlo tras reiniciar OPTI TIRUX.
- Mejorada Timer Consistency con muestreo nativo C#/Stopwatch-QPC y percentiles.
- Mejorada captura DPC/ISR ETW, recuperación de estado de captura y guardado automático al cerrar la aplicación.
- Añadidos accesos a Windows Update, drivers opcionales y aplicaciones de inicio.
- Añadida exportación de informe técnico JSON local.
- Reemplazados paneles falsos restantes de perfiles y ajustes por vistas que describen acciones reales.
- Mejorado el instalador CMD para Windows x64 y Node.js 22.12+.

## Límites conocidos

- No se modifican prioridades de hilos individuales ni afinidad de CPU.
- No se instalan drivers automáticamente.
- La captura ETL no se analiza automáticamente; requiere WPA.
- FPS, frametime y 1% lows aún no se capturan mediante PresentMon.
- No se cambian servicios, registro, Defender, Firewall, VBS/HVCI, BCD, voltajes ni límites térmicos.
